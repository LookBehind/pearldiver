#!/bin/bash
# SaladCloud entrypoint (rev 6): one GPU per container, random per-job nonce start, lowest-latency Kryptex endpoint,
# GPU telemetry, OC capability probe, and a remotely controlled A/B experiment mode.
# Env: PEARL_WALLET (required), PEARL_POOL (overrides auto-select), PEARL_WORKER (prefix), PEARL_M, PEARL_TELEMETRY_S,
#      PEARL_CONTROL_URL (default: salad-control.txt next to this bundle in the repo).
cd "$(dirname "$0")"
: "${PEARL_WALLET:?PEARL_WALLET not set}"
command -v python3 >/dev/null || { apt-get install -y -qq python3-minimal >/dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq python3-minimal >/dev/null 2>&1); }
CTRL_URL=${PEARL_CONTROL_URL:-https://raw.githubusercontent.com/LookBehind/pearldiver/refs/heads/main/salad-control.txt}
ID=${SALAD_MACHINE_ID:-$(hostname)}
WK="${PEARL_WORKER:-salad}$(printf '%s' "$ID" | cksum | cut -d' ' -f1 | cut -c1-6)"
IDX=$(( 12 + $(printf '%s' "$ID" | cksum | cut -d' ' -f1) % 4 ))   # 12..15: never overlaps the rigs' 0..11
API=21373

# --- remote control file (KEY=VALUE lines): MODE=normal|experiment, ARM_MIN, WARM_MIN, ARMS (';'-separated arms,
#     each arm = space-separated KEY=VALUE env overrides; key M sets --m), POOL / WALLET (override env + auto-select;
#     re-read every PEARL_CTRL_POLL_S in normal mode: a change restarts only the miner process, the container keeps its node)
MODE=normal; ARM_MIN=6; WARM_MIN=2; ARMS="base"
if C=$(curl -fsS --max-time 15 "$CTRL_URL?$(date +%s)" 2>/dev/null); then
  while IFS='=' read -r k v; do
    v=${v%$'\r'}
    case "$k" in MODE) MODE=$v;; ARM_MIN) ARM_MIN=$v;; WARM_MIN) WARM_MIN=$v;; ARMS) ARMS=$v;; POOL) CPOOL=$v;; WALLET) CWALLET=$v;; esac
  done <<< "$C"
  echo "[salad] control: MODE=$MODE ARM_MIN=$ARM_MIN ARMS=$ARMS"
else echo "[salad] control file unavailable; MODE=normal"; fi

# --- pool: lowest TCP connect time among Kryptex PRL endpoints (best of 3 tries each)
pick_pool() {
  local best="" bestms=999999 h ms t s e
  for h in prl-ae prl-eu prl-us prl-sg prl-ru prl-br prl-hk; do
    ms=999999
    for t in 1 2 3; do
      s=$(date +%s%N)
      if timeout 3 bash -c "exec 3<>/dev/tcp/$h.kryptex.network/7048" 2>/dev/null; then
        e=$(( ($(date +%s%N) - s) / 1000000 )); (( e < ms )) && ms=$e
      fi
    done
    echo "[salad] pool probe $h: ${ms}ms" >&2
    (( ms < bestms )) && { bestms=$ms; best=$h; }
  done
  echo "${best:-prl-ae}.kryptex.network:7048"
}
BASEPOOL=$PEARL_POOL; BASEWALLET=$PEARL_WALLET          # what we fall back to when POOL=/WALLET= leave the control file
if [ -n "$CPOOL" ]; then POOL=$CPOOL; else [ -z "$BASEPOOL" ] && BASEPOOL=$(pick_pool); POOL=$BASEPOOL; fi
WALLET=${CWALLET:-$BASEWALLET}
PF=/tmp/pearl.pool; WF=/tmp/pearl.wallet; SWF=/tmp/pearl.switch
echo "$POOL" > $PF; echo "$WALLET" > $WF; rm -f $SWF
echo "[salad] worker=$WK idx-base=$IDX pool=$POOL wallet=${WALLET:0:10}…"

# --- kernel path by compute capability: the hand-scheduled loop is sm_86 SASS (runs on 8.6-8.9 = RTX 30/40);
#     9.0+ (e.g. RTX 50 / Blackwell sm_120) falls back to the CUDA kernel JIT-compiled from the embedded PTX
CC=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -1 | tr -d ' ')
if [ -n "$CC" ] && [ "${CC%%.*}" -ge 9 ] 2>/dev/null; then KMODE=""; KDESC="cudart/PTX-JIT (cc $CC)"; else KMODE="PG_MODE=w128h"; KDESC="hand loop w128h (cc ${CC:-?})"; fi
echo "[salad] kernel: $KDESC"

# --- OC capability probe (logged, never fatal)
nvidia-smi --query-gpu=name,driver_version,power.limit,power.min_limit,power.max_limit,clocks.max.sm,clocks.max.mem,pstate --format=csv,noheader 2>&1 | sed 's/^/[salad] gpu: /'
MAXPL=$(nvidia-smi --query-gpu=power.max_limit --format=csv,noheader,nounits 2>/dev/null | head -1 | cut -d. -f1)
[ -n "$MAXPL" ] && echo "[salad] probe -pl $MAXPL: $(nvidia-smi -i 0 -pl "$MAXPL" 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe -lgc: $(nvidia-smi -i 0 -lgc 2100,2100 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe -rgc: $(nvidia-smi -i 0 -rgc 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe -lmc: $(nvidia-smi -i 0 -lmc 810,810 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe -rmc: $(nvidia-smi -i 0 -rmc 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe app-clocks: $(nvidia-smi -i 0 -ac 9501,2100 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe persistence: $(nvidia-smi -i 0 -pm 1 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] after probes: $(nvidia-smi --query-gpu=power.limit,clocks.max.sm --format=csv,noheader 2>&1)"
echo "[salad] cpu: $(nproc) vCPU, $(grep -m1 'model name' /proc/cpuinfo | cut -d: -f2 | xargs), mem $(free -m | awk '/Mem:/{print $2}')MB"

# --- telemetry: clocks / temp / power / throttle reasons
(
  F='clocks.sm,clocks.mem,temperature.gpu,power.draw,power.limit,fan.speed,clocks_event_reasons.active'
  nvidia-smi --query-gpu=$F --format=csv,noheader >/dev/null 2>&1 || F='clocks.sm,clocks.mem,temperature.gpu,power.draw,power.limit,fan.speed,clocks_throttle_reasons.active'
  while sleep "${PEARL_TELEMETRY_S:-120}"; do
    echo "[salad] tele sm,mem,temp,W,PL,fan,reasons: $(nvidia-smi --query-gpu=$F --format=csv,noheader 2>&1 | head -1)"
  done
) &

# total MACs done so far = API total rate x mining_time (independent of --m)
macs_total() { curl -s --max-time 3 http://127.0.0.1:$API | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['algorithms'][0]['hashrate']['gpu']['total']*d['mining_time'], d['mining_time'])" 2>/dev/null; }

run_miner() {   # $1 = arm spec (env overrides; M=<m>)
  local spec="$1" m="${PEARL_M:-8192}" kv
  local envs=(CUDA_DEVICE_ORDER=PCI_BUS_ID PEARL_PIPE=1 PG_IMMA_STALL=0 PG_GROUP_M=32 PG_ASYNC_REORDER=60000 PEARL_RAND_NONCE=1)
  [ -n "$KMODE" ] && envs+=("$KMODE")
  local unset=()
  for kv in $spec; do
    case "$kv" in base) ;; M=*) m=${kv#M=};; UNSET=*) unset+=(-u "${kv#UNSET=}");; *) envs+=("$kv");; esac
  done
  # drop baked defaults that an arm unsets, so `env -u` really removes them
  local final=() e u skip
  for e in "${envs[@]}"; do skip=0; for ((u=1; u<${#unset[@]}; u+=2)); do [ "${e%%=*}" = "${unset[$u]}" ] && skip=1; done; ((skip)) || final+=("$e"); done
  env "${unset[@]}" "${final[@]}" ./pearldiver --pool "$(cat $PF)" --wallet "$(cat $WF)" --worker "$WK" --gpus 0 --idx-base "$IDX" --m "$m" --api-port $API
}

# --- host-quality gate: a node far below what a good host does for this GPU model gets reallocated (IMDS)
GPUNAME=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1)
case "$GPUNAME" in
  *"3090 Ti"*) THR=142;; *3090*) THR=126;; *"3080 Ti"*) THR=121;; *3080*) THR=106;;
  *"3070 Ti"*) THR=77;; *3070*) THR=72;; *"3060 Ti"*) THR=57;;
  *"4090 D"*) THR=260;; *4090*) THR=290;; *4080*) THR=185;; *"4070 Ti SUPER"*|*"4070 Ti Super"*) THR=160;;
  *"4070 Ti"*) THR=150;; *4070*) THR=115;; *) THR=0;;
esac
THR=${PEARL_GATE_THR:-$THR}
gate_check() {   # $1 = measured TH/s ; reallocates (and returns 1) when clearly below threshold
  local r="$1"
  [ "${PEARL_GATE:-1}" = "0" ] || [ "$THR" = "0" ] || [ "$r" = "n/a" ] && return 0
  if python3 -c "import sys; sys.exit(0 if float('$r') < float('$THR') else 1)"; then
    echo "[salad] GATE $GPUNAME rate=$r < thr=$THR TH/s ($(nvidia-smi --query-gpu=clocks.sm,temperature.gpu,power.draw,power.limit --format=csv,noheader 2>&1|head -1)) -> reallocate"
    curl -s -m 10 -X POST -H 'Metadata: true' -H 'Content-Type: application/json' http://169.254.169.254/v1/reallocate \
      -d "{\"reason\":\"pearl host gate: $r < $THR TH/s\"}" -o /dev/null -w "[salad] IMDS reallocate HTTP %{http_code}\n"
    sleep 120; return 1
  fi
  echo "[salad] GATE $GPUNAME rate=$r >= thr=$THR TH/s -> keep"; return 0
}

if [ "$MODE" = "experiment" ] && command -v python3 >/dev/null; then
  IFS=';' read -r -a ARMLIST <<< "$ARMS"
  round=0
  while true; do
    round=$((round+1))
    for arm in "${ARMLIST[@]}"; do
      arm=$(echo "$arm" | xargs)
      run_miner "$arm" > >(grep -E 'error|failed|share|exited' | sed "s/^/[exp:$arm] /") 2>&1 &
      mp=$!
      sleep $(( WARM_MIN * 60 ))
      a=$(macs_total); sleep $(( (ARM_MIN - WARM_MIN) * 60 )); b=$(macs_total)
      tl=$(nvidia-smi --query-gpu=clocks.sm,temperature.gpu,power.draw --format=csv,noheader 2>&1 | head -1)
      kill $mp 2>/dev/null; pkill -x pearldiver 2>/dev/null; wait $mp 2>/dev/null; sleep 3
      r=$(python3 -c "
a='$a'.split(); b='$b'.split()
print('%.2f'%((float(b[0])-float(a[0]))/(float(b[1])-float(a[1]))/1e12) if len(a)==2 and len(b)==2 and float(b[1])>float(a[1]) else 'n/a')")
      echo "[salad] EXP round=$round arm=[$arm] TH/s=$r tele=[$tl]"
      if [ "${GATED:-0}" = "0" ] && [ "$arm" = "base" ]; then GATED=1; gate_check "$r"; fi
    done
  done
fi

rate() {   # $1 $2 = two macs_total samples -> TH/s over the window, or n/a (e.g. miner restarted in between)
  python3 -c "
a='$1'.split(); b='$2'.split()
print('%.2f'%((float(b[0])-float(a[0]))/(float(b[1])-float(a[1]))/1e12) if len(a)==2 and len(b)==2 and float(b[1])>float(a[1]) else 'n/a')"
}
below() { [ "$THR" != "0" ] && [ "$1" != "n/a" ] && python3 -c "import sys; sys.exit(0 if float('$1') < float('$THR') else 1)"; }

# periodic re-check: hosts degrade later (thermals, noisy neighbours); reallocate after 2 consecutive bad windows
if [ "${PEARL_GATE:-1}" != "0" ] && [ "$THR" != "0" ] && command -v python3 >/dev/null; then
  (
    sleep 600; bad=0
    while true; do
      a=$(macs_total); sleep $(( ${PEARL_RECHECK_MIN:-30} * 60 )); b=$(macs_total); r=$(rate "$a" "$b")
      if below "$r"; then bad=$((bad+1)); echo "[salad] RECHECK rate=$r < thr=$THR ($bad/2)"; [ $bad -ge 2 ] && { gate_check "$r"; bad=0; }
      else [ "$r" != "n/a" ] && echo "[salad] RECHECK rate=$r ok"; bad=0; fi
    done
  ) &
fi

# control watcher: hot-switch pool/wallet without restarting the container
(
  while sleep "${PEARL_CTRL_POLL_S:-300}"; do
    C=$(curl -fsS --max-time 15 "$CTRL_URL?$(date +%s)" 2>/dev/null) || continue
    np=$(printf '%s\n' "$C" | sed -n 's/^POOL=//p' | head -1 | tr -d '\r'); nw=$(printf '%s\n' "$C" | sed -n 's/^WALLET=//p' | head -1 | tr -d '\r')
    if [ -z "$np" ]; then [ -z "$BASEPOOL" ] && BASEPOOL=$(pick_pool); np=$BASEPOOL; fi
    nw=${nw:-$BASEWALLET}
    if [ "$np" != "$(cat $PF)" ] || [ "$nw" != "$(cat $WF)" ]; then
      echo "[salad] control: switch pool $(cat $PF) -> $np, wallet $(head -c 10 $WF)… -> ${nw:0:10}…"
      echo "$np" > $PF; echo "$nw" > $WF; touch $SWF; pkill -x pearldiver
    fi
  done
) &

first=1
while true; do
  run_miner "base" &
  mp=$!
  if [ "$first" = "1" ] && command -v python3 >/dev/null; then
    first=0; ( sleep 120; a=$(macs_total); sleep 180; b=$(macs_total); gate_check "$(rate "$a" "$b")" ) &   # background: never blocks restarts
  fi
  wait $mp
  rc=$?
  if [ -f $SWF ]; then rm -f $SWF; echo "[salad] miner stopped for pool/wallet switch; restarting now"; sleep 2
  else echo "[salad] miner exited rc=$rc ; restarting in 60s"; sleep 60; fi   # back off: do not crash-loop (SaladCloud terms 6.19)
done
