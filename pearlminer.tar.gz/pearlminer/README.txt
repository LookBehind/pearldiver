pearlminer — HiveOS custom miner for Pearl (PRL), pearlhash
===========================================================

Single self-contained binary: the tuned hand-loop CUDA kernel is embedded, so
there is no loose .cubin. The binary is stripped and UPX-packed.

INSTALL (HiveOS flight sheet -> create "Custom" miner)
------------------------------------------------------
  Miner name            : pearlminer   (must match the folder name)
  Installation URL      : <URL of this pearlminer.tar.gz>   (http/https, raw)
  Hash algorithm        : pearlhash
  Wallet and worker     : %WAL%.%WORKER_NAME%
  Pool URL              : prl-ae.kryptex.network:7048   (or your pool)
  Pass                  : x
  Extra config arguments: PEARL_UPDATE_URL=<raw base url of your repo>

Set the wallet to your PRL address in the flight sheet as usual.

AUTO OVERCLOCK (RTX 3070)
-------------------------
On start, every detected RTX 3070 / 3070 Ti is set to the recommended Pearl
profile (measured best for $/day at ~48 AMD/kWh; beats WildRig 0.52.3):
    power limit 150 W, memory 810, core offset +250, fan 75%
Override per rig in "Extra config arguments" (space-separated KEY=VALUE):
    PEARL_PL=160 PEARL_COFF=275 PEARL_FAN=100 PEARL_MEM=810
Faster cards that pass a 20-min soak run +275 / 160 W / fan 100 (+~1% $/day).
Disable auto-OC and use the Hive OC profile instead:  PEARL_AUTO_OC=0

AUTO UPDATE
-----------
Auto-update is ON by default, from:
    https://raw.githubusercontent.com/LookBehind/pearldiver/refs/heads/main
Override the source with PEARL_UPDATE_URL=<raw base url>, or turn it off with
PEARL_AUTO_UPDATE=0. The base URL must host two files:
    latest.txt            one line:  <version> <tarball-url> [sha256]
    pearlminer.tar.gz     the package
On start and every 30 min (PEARL_UPDATE_INTERVAL seconds) the miner checks
latest.txt; if <version> is newer than the local VERSION it downloads the
tarball, verifies the optional sha256, extracts over itself and restarts.

Example latest.txt:
    0.4 https://raw.githubusercontent.com/you/repo/main/pearlminer.tar.gz 1f2e...a9

FILES
-----
  pearlminer      self-contained miner (embedded kernel, stripped+UPX)
  h-run.sh        entrypoint: update check -> auto-OC -> launch
  h-config.sh     builds pearlminer.conf + env.conf from the flight sheet
  h-oc.sh         RTX 3070 recommended overclock
  h-update.sh     self-update from PEARL_UPDATE_URL
  h-stats.sh      hashrate/shares to the Hive agent
  h-manifest.conf name/version/api port
  VERSION         package version (used by the updater)
