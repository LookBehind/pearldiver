#!/usr/bin/env bash
# Self-update. Reads a manifest at $PEARL_UPDATE_URL/latest.txt of the form:
#     <version> <tarball-url> [sha256]
# e.g.  0.4  https://raw.githubusercontent.com/you/pearlminer/main/pearlminer.tar.gz  <sha256>
# If <version> is newer than the local VERSION, downloads and extracts over this dir.
# Set the base URL in the flight sheet extras:  PEARL_UPDATE_URL=https://raw.githubusercontent.com/you/pearlminer/main
# Disable with PEARL_AUTO_UPDATE=0.  Returns 0 and prints "pearl update: applied" if it updated.
cd "$(dirname "$0")" || exit 0
. ./h-manifest.conf 2>/dev/null

[[ "${PEARL_AUTO_UPDATE:-1}" == "0" ]] && exit 0
[[ -z "$PEARL_UPDATE_URL" ]] && exit 0

cur=$(cat VERSION 2>/dev/null || echo 0)
man=$(curl -fsS --max-time 15 "${PEARL_UPDATE_URL%/}/latest.txt" 2>/dev/null) || exit 0
read -r new url sum <<< "$man"
[[ -z "$new" || -z "$url" ]] && exit 0
[[ "$new" == "$cur" ]] && exit 0
# only move forward (semantic/version sort)
[[ "$(printf '%s\n%s\n' "$cur" "$new" | sort -V | tail -1)" != "$new" ]] && exit 0

tmp=$(mktemp -d) || exit 0
trap 'rm -rf "$tmp"' EXIT
curl -fsS --max-time 180 "$url" -o "$tmp/p.tgz" || exit 0
if [[ -n "$sum" ]]; then
  echo "$sum  $tmp/p.tgz" | sha256sum -c - >/dev/null 2>&1 || { echo "pearl update: checksum mismatch, skipping"; exit 0; }
fi
tar xzf "$tmp/p.tgz" -C "$tmp" 2>/dev/null || exit 0
src="$tmp/pearlminer"
[[ -f "$src/h-run.sh" ]] || src=$(dirname "$(find "$tmp" -name h-run.sh 2>/dev/null | head -1)")
[[ -f "$src/pearlminer" ]] || { echo "pearl update: bad tarball"; exit 0; }

cp -f "$src"/* ./ 2>/dev/null
chmod +x ./pearlminer ./*.sh 2>/dev/null
echo "pearl update: applied ${cur} -> ${new}"
exit 0
