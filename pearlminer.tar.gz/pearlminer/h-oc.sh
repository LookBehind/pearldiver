#!/usr/bin/env bash
# Auto-OC: on every detected RTX 3070 / 3070 Ti, apply the recommended Pearl settings.
# Disable entirely with PEARL_AUTO_OC=0 (then use the flight sheet OC profile instead).
# Override any value via env (flight sheet "Extra config arguments", e.g. PEARL_COFF=275):
#   PEARL_PL   power limit, W           (default 150)
#   PEARL_MEM  memory clock lock, MHz   (default 810)
#   PEARL_COFF core clock offset, MHz   (default 250; 275 is faster on cards that pass a 20-min soak)
#   PEARL_FAN  fan speed, %             (default 75; 100 lets weaker cards hold a higher offset)
# Recommended = measured best for RTX 3070 @ 130 W rig budget: beats WildRig 0.52.3 on $/day.

[[ "${PEARL_AUTO_OC:-1}" == "0" ]] && { echo "pearl auto-OC: disabled (PEARL_AUTO_OC=0)"; return 0 2>/dev/null || exit 0; }

PL=${PEARL_PL:-150}
MEM=${PEARL_MEM:-810}
COFF=${PEARL_COFF:-250}
FAN=${PEARL_FAN:-75}
NVT=/hive/sbin/nvtool

mapfile -t NAMES < <(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null)
applied=0
for i in "${!NAMES[@]}"; do
  if [[ "${NAMES[$i]}" == *3070* ]]; then
    nvidia-smi -i "$i" -pl "$PL"            >/dev/null 2>&1
    nvidia-smi -i "$i" -lmc "${MEM},${MEM}" >/dev/null 2>&1
    [[ -x "$NVT" ]] && "$NVT" -i "$i" --setcoreoffset "$COFF" >/dev/null 2>&1
    [[ -x "$NVT" ]] && "$NVT" -i "$i" --setmemoffset 0        >/dev/null 2>&1
    [[ -n "$FAN" && -x "$NVT" ]] && "$NVT" -i "$i" --setfan "$FAN" >/dev/null 2>&1
    echo "pearl auto-OC: gpu$i ${NAMES[$i]} -> PL=${PL}W mem=${MEM} coff=+${COFF} fan=${FAN}%"
    applied=$((applied+1))
  fi
done
[[ $applied -eq 0 ]] && echo "pearl auto-OC: no RTX 3070 detected, leaving clocks untouched"
return 0 2>/dev/null || exit 0
