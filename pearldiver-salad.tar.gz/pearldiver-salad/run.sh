#!/bin/bash
# SaladCloud entrypoint: one GPU per container, stock clocks (no OC on cloud hosts), random per-job nonce start.
# Env: PEARL_WALLET (required), PEARL_POOL, PEARL_WORKER (prefix), PEARL_M.
cd "$(dirname "$0")"
export CUDA_DEVICE_ORDER=PCI_BUS_ID PEARL_PIPE=1 PG_MODE=w128h PG_IMMA_STALL=0 PG_GROUP_M=32 PG_ASYNC_REORDER=60000 PEARL_RAND_NONCE=1
: "${PEARL_WALLET:?PEARL_WALLET not set}"
POOL=${PEARL_POOL:-prl-ae.kryptex.network:7048}
ID=${SALAD_MACHINE_ID:-$(hostname)}
WK="${PEARL_WORKER:-salad}$(printf '%s' "$ID" | cksum | cut -d' ' -f1 | cut -c1-6)"
IDX=$(( 12 + $(printf '%s' "$ID" | cksum | cut -d' ' -f1) % 4 ))   # 12..15: never overlaps the rigs' 0..11
echo "[salad] worker=$WK idx-base=$IDX pool=$POOL"
nvidia-smi --query-gpu=name,driver_version,power.limit,clocks.max.sm --format=csv,noheader 2>/dev/null || echo "[salad] nvidia-smi unavailable"
while true; do
  ./pearldiver --pool "$POOL" --wallet "$PEARL_WALLET" --worker "$WK" --gpus 0 --idx-base "$IDX" --m "${PEARL_M:-4096}" --api-port 21373
  echo "[salad] miner exited rc=$? ; restarting in 60s"; sleep 60   # back off: do not crash-loop (SaladCloud terms 6.19)
done
