#!/bin/bash
# SaladCloud entrypoint (rev 3): one GPU per container, random per-job nonce start, lowest-latency Kryptex endpoint,
# GPU telemetry, OC capability probe, and a remotely controlled A/B experiment mode.
# Env: PEARL_WALLET (required), PEARL_POOL (overrides auto-select), PEARL_WORKER (prefix), PEARL_M, PEARL_TELEMETRY_S,
#      PEARL_CONTROL_URL (default: salad-control.txt next to this bundle in the repo).
cd "$(dirname "$0")"
: "${PEARL_WALLET:?PEARL_WALLET not set}"
command -v python3 >/dev/null || { apt-get install -y -qq python3-minimal >/dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq python3-minimal >/dev/null 2>&1); }
CTRL_URL=${PEARL_CONTROL_URL:-https://raw.githubusercontent.com/LookBehind/pearldiver/refs/heads/main/salad-control.txt}
ID=${SALAD_MACHINE_ID:-$(hostname)}
WK="${PEARL_WORKER:-salad}$(printf '%s' "$ID" | cksum | cut -d' ' -f1 | cut -c1-6)"
IDX=$(( 12 + $(printf '%s' "$ID" | cksum | cut -d' ' -f1) % 4 ))   # 12..15: never overlaps the rigs' 0..11
API=21373

# --- remote control file (KEY=VALUE lines): MODE=normal|experiment, ARM_MIN, WARM_MIN, ARMS (';'-separated arms,
#     each arm = space-separated KEY=VALUE env overrides; key M sets --m)
MODE=normal; ARM_MIN=6; WARM_MIN=2; ARMS="base"
if C=$(curl -fsS --max-time 15 "$CTRL_URL?$(date +%s)" 2>/dev/null); then
  while IFS='=' read -r k v; do
    case "$k" in MODE) MODE=$v;; ARM_MIN) ARM_MIN=$v;; WARM_MIN) WARM_MIN=$v;; ARMS) ARMS=$v;; esac
  done <<< "$C"
  echo "[salad] control: MODE=$MODE ARM_MIN=$ARM_MIN ARMS=$ARMS"
else echo "[salad] control file unavailable; MODE=normal"; fi

# --- pool: lowest TCP connect time among Kryptex PRL endpoints (best of 3 tries each)
pick_pool() {
  local best="" bestms=999999 h ms t s e
  for h in prl-ae prl-eu prl-us prl-sg prl-ru prl-br prl-hk; do
    ms=999999
    for t in 1 2 3; do
      s=$(date +%s%N)
      if timeout 3 bash -c "exec 3<>/dev/tcp/$h.kryptex.network/7048" 2>/dev/null; then
        e=$(( ($(date +%s%N) - s) / 1000000 )); (( e < ms )) && ms=$e
      fi
    done
    echo "[salad] pool probe $h: ${ms}ms" >&2
    (( ms < bestms )) && { bestms=$ms; best=$h; }
  done
  echo "${best:-prl-ae}.kryptex.network:7048"
}
POOL=${PEARL_POOL:-$(pick_pool)}
echo "[salad] worker=$WK idx-base=$IDX pool=$POOL"

# --- OC capability probe (logged, never fatal)
nvidia-smi --query-gpu=name,driver_version,power.limit,power.min_limit,power.max_limit,clocks.max.sm,clocks.max.mem,pstate --format=csv,noheader 2>&1 | sed 's/^/[salad] gpu: /'
MAXPL=$(nvidia-smi --query-gpu=power.max_limit --format=csv,noheader,nounits 2>/dev/null | head -1 | cut -d. -f1)
[ -n "$MAXPL" ] && echo "[salad] probe -pl $MAXPL: $(nvidia-smi -i 0 -pl "$MAXPL" 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe -lgc: $(nvidia-smi -i 0 -lgc 2100,2100 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe -rgc: $(nvidia-smi -i 0 -rgc 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe -lmc: $(nvidia-smi -i 0 -lmc 810,810 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe -rmc: $(nvidia-smi -i 0 -rmc 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe app-clocks: $(nvidia-smi -i 0 -ac 9501,2100 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] probe persistence: $(nvidia-smi -i 0 -pm 1 2>&1 | tr '\n' ' ' | cut -c1-200)"
echo "[salad] after probes: $(nvidia-smi --query-gpu=power.limit,clocks.max.sm --format=csv,noheader 2>&1)"
echo "[salad] cpu: $(nproc) vCPU, $(grep -m1 'model name' /proc/cpuinfo | cut -d: -f2 | xargs), mem $(free -m | awk '/Mem:/{print $2}')MB"

# --- telemetry: clocks / temp / power / throttle reasons
(
  F='clocks.sm,clocks.mem,temperature.gpu,power.draw,power.limit,fan.speed,clocks_event_reasons.active'
  nvidia-smi --query-gpu=$F --format=csv,noheader >/dev/null 2>&1 || F='clocks.sm,clocks.mem,temperature.gpu,power.draw,power.limit,fan.speed,clocks_throttle_reasons.active'
  while sleep "${PEARL_TELEMETRY_S:-120}"; do
    echo "[salad] tele sm,mem,temp,W,PL,fan,reasons: $(nvidia-smi --query-gpu=$F --format=csv,noheader 2>&1 | head -1)"
  done
) &

# total MACs done so far = API total rate x mining_time (independent of --m)
macs_total() { curl -s --max-time 3 http://127.0.0.1:$API | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['algorithms'][0]['hashrate']['gpu']['total']*d['mining_time'], d['mining_time'])" 2>/dev/null; }

run_miner() {   # $1 = arm spec (env overrides; M=<m>)
  local spec="$1" m="${PEARL_M:-4096}" kv
  local envs=(CUDA_DEVICE_ORDER=PCI_BUS_ID PEARL_PIPE=1 PG_MODE=w128h PG_IMMA_STALL=0 PG_GROUP_M=32 PG_ASYNC_REORDER=60000 PEARL_RAND_NONCE=1)
  local unset=()
  for kv in $spec; do
    case "$kv" in base) ;; M=*) m=${kv#M=};; UNSET=*) unset+=(-u "${kv#UNSET=}");; *) envs+=("$kv");; esac
  done
  # drop baked defaults that an arm unsets, so `env -u` really removes them
  local final=() e u skip
  for e in "${envs[@]}"; do skip=0; for ((u=1; u<${#unset[@]}; u+=2)); do [ "${e%%=*}" = "${unset[$u]}" ] && skip=1; done; ((skip)) || final+=("$e"); done
  env "${unset[@]}" "${final[@]}" ./pearldiver --pool "$POOL" --wallet "$PEARL_WALLET" --worker "$WK" --gpus 0 --idx-base "$IDX" --m "$m" --api-port $API
}

if [ "$MODE" = "experiment" ] && command -v python3 >/dev/null; then
  IFS=';' read -r -a ARMLIST <<< "$ARMS"
  round=0
  while true; do
    round=$((round+1))
    for arm in "${ARMLIST[@]}"; do
      arm=$(echo "$arm" | xargs)
      run_miner "$arm" > >(grep -E 'error|failed|share|exited' | sed "s/^/[exp:$arm] /") 2>&1 &
      mp=$!
      sleep $(( WARM_MIN * 60 ))
      a=$(macs_total); sleep $(( (ARM_MIN - WARM_MIN) * 60 )); b=$(macs_total)
      tl=$(nvidia-smi --query-gpu=clocks.sm,temperature.gpu,power.draw --format=csv,noheader 2>&1 | head -1)
      kill $mp 2>/dev/null; pkill -x pearldiver 2>/dev/null; wait $mp 2>/dev/null; sleep 3
      r=$(python3 -c "
a='$a'.split(); b='$b'.split()
print('%.2f'%((float(b[0])-float(a[0]))/(float(b[1])-float(a[1]))/1e12) if len(a)==2 and len(b)==2 and float(b[1])>float(a[1]) else 'n/a')")
      echo "[salad] EXP round=$round arm=[$arm] TH/s=$r tele=[$tl]"
    done
  done
fi

while true; do
  run_miner "base"
  echo "[salad] miner exited rc=$? ; restarting in 60s"; sleep 60   # back off: do not crash-loop (SaladCloud terms 6.19)
done
