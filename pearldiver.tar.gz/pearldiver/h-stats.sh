#!/usr/bin/env bash
# Sets $khs and $stats for the Hive agent from the miner's JSON API.
. /hive/miners/custom/pearldiver/h-manifest.conf
j=$(curl -s --max-time 3 http://127.0.0.1:${MINER_API_PORT})
if [[ -z "$j" ]]; then
  khs=0; stats=null
else
  gpus=$(echo "$j" | jq -r '.algorithms[0].hashrate.gpu | to_entries | map(select(.key!="total")) | sort_by(.key|ltrimstr("gpu")|tonumber) | map(.key|ltrimstr("gpu")) | join(",")')
  hs=$(echo "$j" | jq -c '[.algorithms[0].hashrate.gpu | to_entries[] | select(.key!="total") | {i:(.key|ltrimstr("gpu")|tonumber), v:(.value/1000)}] | sort_by(.i) | map(.v)')
  khs=$(echo "$j" | jq '.algorithms[0].hashrate.gpu.total/1000')
  q=$(nvidia-smi -i $gpus --query-gpu=temperature.gpu,fan.speed,pci.bus --format=csv,noheader,nounits)
  temp=$(echo "$q" | awk -F', ' '{print $1}' | jq -cs .)
  fan=$(echo "$q" | awk -F', ' '{print $2}' | jq -cs .)
  bus=$(echo "$q" | while IFS=", " read -r a b c; do echo $((c)); done | jq -cs .)
  acc=$(echo "$j" | jq '.algorithms[0].shares.accepted')
  rej=$(echo "$j" | jq '.algorithms[0].shares.rejected')
  up=$(echo "$j" | jq '.mining_time')
  stats=$(jq -nc --argjson hs "$hs" --argjson t "$temp" --argjson f "$fan" --argjson b "$bus" --arg acc "$acc" --arg rej "$rej" --arg up "$up" \
    '{hs:$hs, hs_units:"khs", temp:$t, fan:$f, bus_numbers:$b, uptime:($up|tonumber), ar:[($acc|tonumber),($rej|tonumber)], algo:"pearlhash", ver:"0.3"}')
fi
[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats=null
