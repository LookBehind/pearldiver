#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
. h-manifest.conf
[[ -z $CUSTOM_LOG_BASENAME ]] && echo "No CUSTOM_LOG_BASENAME" && exit 1
mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
LOG=${CUSTOM_LOG_BASENAME}.log

# flight-sheet PEARL_* overrides (written by h-config.sh)
[[ -f env.conf ]] && . ./env.conf

# default self-update source (override in the flight sheet with PEARL_UPDATE_URL=...)
export PEARL_UPDATE_URL=${PEARL_UPDATE_URL:-https://raw.githubusercontent.com/LookBehind/pearldiver/refs/heads/main}

# one synchronous self-update before launch, then re-read overrides in case it changed
./h-update.sh >> "$LOG" 2>&1
[[ -f env.conf ]] && . ./env.conf

# recommended overclock for detected RTX 3070s (no-op if PEARL_AUTO_OC=0 or no 3070)
. ./h-oc.sh >> "$LOG" 2>&1

# background updater (on by default): on a newer version, apply it and drop the miner so Hive restarts us
UPDATER=""
if [[ "${PEARL_AUTO_UPDATE:-1}" != "0" && -n "$PEARL_UPDATE_URL" ]]; then
  (
    while sleep "${PEARL_UPDATE_INTERVAL:-1800}"; do
      out=$(./h-update.sh 2>/dev/null)
      [[ -n "$out" ]] && echo "$out" >> "$LOG"
      if echo "$out" | grep -q 'pearl update: applied'; then
        echo "pearl update: restarting miner" >> "$LOG"
        pkill -x pearldiver 2>/dev/null
        exit 0
      fi
    done
  ) &
  UPDATER=$!
fi

export CUDA_DEVICE_ORDER=PCI_BUS_ID
export PEARL_PIPE=1 PG_MODE=w128h PG_IMMA_STALL=0 PG_GROUP_M=32
export PG_ASYNC_REORDER=${PG_ASYNC_REORDER:-60000}

./pearldiver $(< "$CUSTOM_CONFIG_FILENAME") 2>&1 | tee --append "$LOG"

[[ -n "$UPDATER" ]] && kill "$UPDATER" 2>/dev/null
