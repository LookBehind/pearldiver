#!/usr/bin/env bash
# Builds pearldiver.conf (miner CLI args) and env.conf (PEARL_* overrides) from the Hive flight sheet.
# In the flight sheet "Extra config arguments" box you may mix miner flags and PEARL_* overrides, e.g.:
#     PEARL_COFF=275 PEARL_PL=160 PEARL_FAN=100 --m 4096
cd `dirname $0`
. h-manifest.conf

wal="$CUSTOM_TEMPLATE"
[[ -z "$wal" ]] && wal="$CUSTOM_WALLET"
addr="${wal%%.*}"
wrk="${wal#*.}"
[[ "$wrk" == "$wal" || -z "$wrk" ]] && wrk="$WORKER_NAME"

args="--pool $CUSTOM_URL --wallet $addr --worker $wrk --api-port $MINER_API_PORT"
: > env.conf
have_m=0; have_gpus=0
for tok in $CUSTOM_USER_CONFIG; do
  if [[ "$tok" == *=* && "$tok" != --* ]]; then
    echo "export $tok" >> env.conf
  else
    args="$args $tok"
    [[ "$tok" == "--m" ]] && have_m=1
    [[ "$tok" == "--gpus" ]] && have_gpus=1
  fi
done
[[ $have_m -eq 0 ]] && args="$args --m 4096"
# default to ALL detected GPUs (the miner otherwise uses only GPU 0)
if [[ $have_gpus -eq 0 ]]; then
  gl=$(nvidia-smi --query-gpu=index --format=csv,noheader 2>/dev/null | paste -sd, -)
  [[ -n "$gl" ]] && args="$args --gpus $gl"
fi

echo "$args" > $CUSTOM_CONFIG_FILENAME
